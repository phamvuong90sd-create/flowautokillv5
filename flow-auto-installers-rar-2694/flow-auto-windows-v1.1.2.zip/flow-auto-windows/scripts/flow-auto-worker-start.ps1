$ErrorActionPreference = 'Stop'

$ws = 'C:\Users\Administrator\.openclaw\workspace'
$workerScript = Join-Path $ws 'scripts\flow_queue_worker.py'

# Avoid duplicate workers
$existing = Get-CimInstance Win32_Process |
  Where-Object { $_.CommandLine -match 'flow_queue_worker.py' -and $_.CommandLine -notmatch 'Get-CimInstance Win32_Process' }
if ($existing) {
  Write-Output "flow worker already running"
  exit 0
}

Set-Location $ws
$env:FLOW_WORKSPACE = $ws
$env:FLOW_INBOUND_DIR = 'C:\Users\Administrator\.openclaw\media\inbound'
$env:FLOW_QUEUE_DIR = Join-Path $ws 'flow-auto'
$env:FLOW_POLL_SEC = '8'

Start-Process -FilePath 'uv' -ArgumentList @('run','python',$workerScript) -WindowStyle Hidden
Write-Output "flow worker started"
exit 0
