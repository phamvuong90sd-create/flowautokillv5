$ErrorActionPreference = 'Stop'

$ws = if ($env:FLOW_WORKSPACE) { $env:FLOW_WORKSPACE } else { Join-Path $env:USERPROFILE '.openclaw\workspace' }
$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$bundleRoot = Split-Path -Parent $bundleRoot

Write-Host "[flow-installer] Workspace: $ws"

New-Item -ItemType Directory -Force -Path $ws | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $ws 'scripts') | Out-Null
New-Item -ItemType Directory -Force -Path (Join-Path $ws 'flow-auto\job-state') | Out-Null

Copy-Item -Force (Join-Path $bundleRoot 'scripts\flow_batch_runner.py') (Join-Path $ws 'scripts\flow_batch_runner.py')
Copy-Item -Force (Join-Path $bundleRoot 'scripts\flow_queue_worker.py') (Join-Path $ws 'scripts\flow_queue_worker.py')
Copy-Item -Force (Join-Path $bundleRoot 'scripts\flow-auto-worker-start.ps1') (Join-Path $ws 'scripts\flow-auto-worker-start.ps1')

if (-not (Get-Command uv -ErrorAction SilentlyContinue)) {
  throw "Không tìm thấy uv trong PATH. Hãy cài uv trước: https://docs.astral.sh/uv/getting-started/installation/"
}

Set-Location $ws

$venvPython = Join-Path $ws '.venv-flow\Scripts\python.exe'
if (-not (Test-Path $venvPython)) {
  uv venv (Join-Path $ws '.venv-flow')
}

uv pip install --python $venvPython --upgrade pip
uv pip install --python $venvPython playwright requests striprtf
& $venvPython -m playwright install chromium

$taskName = 'OpenClaw-FlowAuto-Worker'
$action = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -File `"$ws\scripts\flow-auto-worker-start.ps1`""
$trigger = New-ScheduledTaskTrigger -AtLogOn
$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -LogonType Interactive -RunLevel Highest

try { Unregister-ScheduledTask -TaskName $taskName -Confirm:$false -ErrorAction Stop } catch {}
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $principal | Out-Null
Start-ScheduledTask -TaskName $taskName

Write-Host "[flow-installer] OK: Installed + scheduled task created ($taskName)."
