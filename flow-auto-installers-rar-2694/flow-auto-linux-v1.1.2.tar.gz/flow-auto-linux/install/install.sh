#!/usr/bin/env bash
set -euo pipefail

WS="${FLOW_WORKSPACE:-$HOME/.openclaw/workspace}"
BUNDLE_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

mkdir -p "$WS/scripts" "$WS/flow-auto/job-state"
cp -f "$BUNDLE_ROOT/scripts/flow_batch_runner.py" "$WS/scripts/flow_batch_runner.py"
cp -f "$BUNDLE_ROOT/scripts/flow_queue_worker.py" "$WS/scripts/flow_queue_worker.py"

if ! command -v uv >/dev/null 2>&1; then
  echo "[error] uv chưa có trong PATH. Cài trước: https://docs.astral.sh/uv/getting-started/installation/"
  exit 1
fi

cd "$WS"
if [ ! -x "$WS/.venv-flow/bin/python" ]; then
  uv venv "$WS/.venv-flow"
fi

uv pip install --python "$WS/.venv-flow/bin/python" --upgrade pip
uv pip install --python "$WS/.venv-flow/bin/python" playwright requests striprtf
"$WS/.venv-flow/bin/python" -m playwright install chromium

mkdir -p "$HOME/.config/systemd/user"
cat > "$HOME/.config/systemd/user/openclaw-flow-auto-worker.service" <<'EOF'
[Unit]
Description=OpenClaw Flow Auto Worker
After=default.target

[Service]
Type=simple
WorkingDirectory=%h/.openclaw/workspace
Environment=FLOW_WORKSPACE=%h/.openclaw/workspace
Environment=FLOW_INBOUND_DIR=%h/.openclaw/media/inbound
Environment=FLOW_QUEUE_DIR=%h/.openclaw/workspace/flow-auto
ExecStart=uv run python %h/.openclaw/workspace/scripts/flow_queue_worker.py
Restart=always
RestartSec=5

[Install]
WantedBy=default.target
EOF

systemctl --user daemon-reload
systemctl --user enable --now openclaw-flow-auto-worker.service

echo "[flow-installer] OK: installed and started service openclaw-flow-auto-worker.service"
